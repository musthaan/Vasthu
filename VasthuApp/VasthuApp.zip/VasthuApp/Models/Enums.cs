﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VasthuApp.Models
{
    public enum EntryMode
    {
        New,
        Edit
    }
}
